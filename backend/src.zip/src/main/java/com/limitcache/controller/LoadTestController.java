package com.limitcache.controller;

import com.limitcache.model.LimitDTOs.*;
import com.limitcache.service.LimitService;
import io.micrometer.core.instrument.MeterRegistry;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Controller for running load tests to compare cache vs direct DB performance.
 * This demonstrates the dramatic improvement in throughput and latency.
 */
@RestController
@RequestMapping("/api/demo")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Load Test", description = "Performance comparison endpoints")
@CrossOrigin(origins = "*")
public class LoadTestController {

    private final LimitService limitService;
    private final MeterRegistry meterRegistry;

    @PostMapping("/load-test")
    @Operation(summary = "Run a load test", description = "Simulates concurrent transactions to measure performance")
    public ResponseEntity<ApiResponse<LoadTestResponse>> runLoadTest(
            @RequestBody(required = false) LoadTestRequest request) {
        
        if (request == null) {
            request = LoadTestRequest.builder()
                    .threads(50)
                    .durationSeconds(10)
                    .minAmount(100)
                    .maxAmount(1000)
                    .useCache(true)
                    .build();
        }
        
        log.info("Starting load test: {} threads, {} seconds, useCache: {}", 
                request.getThreads(), request.getDurationSeconds(), request.isUseCache());
        
        LoadTestResponse response = executeLoadTest(request);
        
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PostMapping("/comparison-test")
    @Operation(summary = "Run comparison test", description = "Compares cache vs direct DB performance")
    public ResponseEntity<ApiResponse<ComparisonResponse>> runComparisonTest(
            @RequestParam(defaultValue = "20") int threads,
            @RequestParam(defaultValue = "10") int durationSeconds) {
        
        log.info("Starting comparison test: {} threads, {} seconds", threads, durationSeconds);
        
        // First, reset limits
        limitService.resetLimits(LocalDate.now().getYear(), LocalDate.now().getMonthValue());
        
        // Run with cache
        LoadTestRequest cacheRequest = LoadTestRequest.builder()
                .threads(threads)
                .durationSeconds(durationSeconds)
                .useCache(true)
                .build();
        LoadTestResponse cacheResults = executeLoadTest(cacheRequest);
        
        // Reset limits again
        limitService.resetLimits(LocalDate.now().getYear(), LocalDate.now().getMonthValue());
        
        // Small delay between tests
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Run with direct DB
        LoadTestRequest dbRequest = LoadTestRequest.builder()
                .threads(threads)
                .durationSeconds(durationSeconds)
                .useCache(false)
                .build();
        LoadTestResponse dbResults = executeLoadTest(dbRequest);
        
        // Calculate improvement
        double throughputImprovement = cacheResults.getThroughputTps() / 
                Math.max(dbResults.getThroughputTps(), 0.1);
        double latencyReduction = 100.0 * (1.0 - (cacheResults.getAvgLatencyMs() / 
                Math.max(dbResults.getAvgLatencyMs(), 0.1)));
        double successRateImprovement = cacheResults.getSuccessfulRequests() * 100.0 / 
                Math.max(cacheResults.getTotalRequests(), 1) -
                dbResults.getSuccessfulRequests() * 100.0 / Math.max(dbResults.getTotalRequests(), 1);
        
        ImprovementMetrics improvement = ImprovementMetrics.builder()
                .throughputImprovement(throughputImprovement)
                .latencyReduction(latencyReduction)
                .successRateImprovement(successRateImprovement)
                .summary(String.format(
                        "Cache provides %.1fx throughput, %.0f%% lower latency",
                        throughputImprovement, latencyReduction))
                .build();
        
        ComparisonResponse response = ComparisonResponse.builder()
                .cacheResults(cacheResults)
                .directDbResults(dbResults)
                .improvement(improvement)
                .build();
        
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/quick-test")
    @Operation(summary = "Quick performance test", description = "Runs a quick 5-second test")
    public ResponseEntity<ApiResponse<LoadTestResponse>> quickTest(
            @RequestParam(defaultValue = "true") boolean useCache) {
        
        LoadTestRequest request = LoadTestRequest.builder()
                .threads(20)
                .durationSeconds(5)
                .useCache(useCache)
                .build();
        
        LoadTestResponse response = executeLoadTest(request);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    /**
     * Execute the actual load test
     */
    private LoadTestResponse executeLoadTest(LoadTestRequest request) {
        int threads = Math.min(request.getThreads(), 200); // Cap at 200 threads
        int durationSeconds = Math.min(request.getDurationSeconds(), 60); // Cap at 60 seconds
        boolean useCache = request.isUseCache();
        
        ExecutorService executor = Executors.newFixedThreadPool(threads);
        
        AtomicInteger totalRequests = new AtomicInteger(0);
        AtomicInteger successfulRequests = new AtomicInteger(0);
        AtomicInteger failedRequests = new AtomicInteger(0);
        AtomicLong totalLatency = new AtomicLong(0);
        ConcurrentLinkedQueue<Long> latencies = new ConcurrentLinkedQueue<>();
        
        Random random = new Random();
        LocalDate today = LocalDate.now();
        
        long startTime = System.currentTimeMillis();
        long endTime = startTime + (durationSeconds * 1000L);
        
        // Submit worker tasks
        List<Future<?>> futures = new ArrayList<>();
        for (int i = 0; i < threads; i++) {
            futures.add(executor.submit(() -> {
                while (System.currentTimeMillis() < endTime) {
                    try {
                        // Random amount between min and max
                        long amount = request.getMinAmount() + 
                                random.nextInt(request.getMaxAmount() - request.getMinAmount());
                        
                        // Random day in current month (to spread load)
                        int dayOffset = random.nextInt(7); // Current day +/- few days
                        LocalDate targetDate = today.plusDays(dayOffset);
                        
                        ConsumeRequest consumeRequest = ConsumeRequest.builder()
                                .date(targetDate)
                                .amount(amount)
                                .forceDirectDb(!useCache)
                                .build();
                        
                        long reqStart = System.currentTimeMillis();
                        ConsumeResponse response = limitService.consumeLimit(consumeRequest);
                        long latency = System.currentTimeMillis() - reqStart;
                        
                        totalRequests.incrementAndGet();
                        totalLatency.addAndGet(latency);
                        latencies.add(latency);
                        
                        if (response.isSuccess()) {
                            successfulRequests.incrementAndGet();
                        } else {
                            failedRequests.incrementAndGet();
                        }
                        
                    } catch (Exception e) {
                        totalRequests.incrementAndGet();
                        failedRequests.incrementAndGet();
                    }
                }
            }));
        }
        
        // Wait for completion
        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (Exception e) {
                log.warn("Worker thread error: {}", e.getMessage());
            }
        }
        
        executor.shutdown();
        
        long actualDuration = System.currentTimeMillis() - startTime;
        
        // Calculate percentiles
        List<Long> sortedLatencies = new ArrayList<>(latencies);
        Collections.sort(sortedLatencies);
        
        double p95 = 0, p99 = 0, avg = 0;
        if (!sortedLatencies.isEmpty()) {
            avg = totalLatency.get() / (double) sortedLatencies.size();
            int p95Index = (int) (sortedLatencies.size() * 0.95);
            int p99Index = (int) (sortedLatencies.size() * 0.99);
            p95 = sortedLatencies.get(Math.min(p95Index, sortedLatencies.size() - 1));
            p99 = sortedLatencies.get(Math.min(p99Index, sortedLatencies.size() - 1));
        }
        
        double throughput = totalRequests.get() * 1000.0 / actualDuration;
        
        log.info("Load test completed: {} requests, {} success, {} failed, {:.2f} TPS, {:.2f}ms avg latency",
                totalRequests.get(), successfulRequests.get(), failedRequests.get(), 
                throughput, avg);
        
        return LoadTestResponse.builder()
                .completed(true)
                .totalRequests(totalRequests.get())
                .successfulRequests(successfulRequests.get())
                .failedRequests(failedRequests.get())
                .avgLatencyMs(avg)
                .p95LatencyMs(p95)
                .p99LatencyMs(p99)
                .throughputTps(throughput)
                .durationMs(actualDuration)
                .mode(useCache ? "CACHE_ENABLED" : "DIRECT_DB")
                .message(String.format("Completed %d requests in %dms", 
                        totalRequests.get(), actualDuration))
                .build();
    }
}
